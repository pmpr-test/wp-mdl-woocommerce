<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b810ef35             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce; use Pmpr\Common\Cover\Woocommerce\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { const qqiuqmkwamakmmky = self::soqkucakwksaeyce . "\x76\141\162\151\141\x62\154\x65\x5f\160\162\157\144\x75\x63\x74\x5f\147\x75\151\x64\x65"; const kqaecmeyeicscaye = self::soqkucakwksaeyce . "\x73\x68\x6f\x70\x5f\164\141\142\x6c\145\137\x76\x69\x65\167\x5f\x63\157\154\165\x6d\x6e\x73"; public function qssqicawwgqqscui($ikgwqyuyckaewsow = []) { return $this->oaeygwkmgmgksqke([self::qqiuqmkwamakmmky => [Constants::qescuiwgsyuikume => __("\126\141\x72\x69\141\x74\x69\x6f\x6e\40\x50\x72\x6f\144\165\143\164\40\107\165\x69\144\145", PR__MDL__WOOCOMMERCE)]], $ikgwqyuyckaewsow, self::imgaumeywmqsacas); } public static function ckgyyysykiycqwwm() { return self::iwgqamekocwaigci()->wikusamwomuogoau()->giiuwsmyumqwwiyq(self::qqiuqmkwamakmmky, ''); } }
