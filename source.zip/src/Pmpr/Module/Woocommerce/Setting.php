<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705dc8900e6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce; use Pmpr\Common\Cover\Woocommerce\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { const qqiuqmkwamakmmky = self::soqkucakwksaeyce . "\166\x61\162\x69\141\x62\154\145\x5f\160\x72\x6f\144\165\x63\164\x5f\x67\165\151\144\x65"; const kqaecmeyeicscaye = self::soqkucakwksaeyce . "\163\150\157\x70\137\x74\141\142\154\145\137\x76\x69\145\167\137\x63\157\x6c\x75\155\156\163"; public function qssqicawwgqqscui($ikgwqyuyckaewsow = []) { return $this->oaeygwkmgmgksqke([self::qqiuqmkwamakmmky => [Constants::qescuiwgsyuikume => __("\126\x61\162\x69\x61\x74\x69\157\156\40\120\x72\x6f\144\x75\x63\164\x20\107\x75\x69\x64\x65", PR__MDL__WOOCOMMERCE)]], $ikgwqyuyckaewsow, self::imgaumeywmqsacas); } public static function ckgyyysykiycqwwm() { return self::iwgqamekocwaigci()->wikusamwomuogoau()->giiuwsmyumqwwiyq(self::qqiuqmkwamakmmky, ''); } }
