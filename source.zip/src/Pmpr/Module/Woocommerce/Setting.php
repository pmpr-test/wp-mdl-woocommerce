<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6801066135453             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce; use Pmpr\Common\Cover\Woocommerce\AbstractSetting; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends AbstractSetting { const qqiuqmkwamakmmky = self::soqkucakwksaeyce . 'variable_product_guide'; const kqaecmeyeicscaye = self::soqkucakwksaeyce . 'shop_table_view_columns'; public function qssqicawwgqqscui($ikgwqyuyckaewsow = []) { return $this->oaeygwkmgmgksqke([self::qqiuqmkwamakmmky => [Constants::qescuiwgsyuikume => __('Variation Product Guide', PR__MDL__WOOCOMMERCE)]], $ikgwqyuyckaewsow, self::imgaumeywmqsacas); } public static function ckgyyysykiycqwwm() { return self::iwgqamekocwaigci()->wikusamwomuogoau()->giiuwsmyumqwwiyq(self::qqiuqmkwamakmmky, ''); } }
