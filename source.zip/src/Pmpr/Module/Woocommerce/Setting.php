<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d47024bfbe             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce; use Pmpr\Common\Cover\Woocommerce\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { const qqiuqmkwamakmmky = self::soqkucakwksaeyce . "\x76\x61\x72\x69\x61\x62\x6c\x65\x5f\x70\162\x6f\144\x75\143\x74\x5f\x67\x75\151\x64\145"; const kqaecmeyeicscaye = self::soqkucakwksaeyce . "\x73\x68\157\x70\x5f\164\x61\142\x6c\x65\x5f\x76\x69\x65\x77\137\x63\157\154\165\155\156\x73"; public function qssqicawwgqqscui($ikgwqyuyckaewsow = []) { return $this->oaeygwkmgmgksqke([self::qqiuqmkwamakmmky => [Constants::qescuiwgsyuikume => __("\x56\141\162\x69\141\164\151\x6f\156\x20\120\162\157\144\165\x63\x74\x20\x47\165\x69\144\x65", PR__MDL__WOOCOMMERCE)]], $ikgwqyuyckaewsow, self::imgaumeywmqsacas); } public static function ckgyyysykiycqwwm() { return self::iwgqamekocwaigci()->wikusamwomuogoau()->giiuwsmyumqwwiyq(self::qqiuqmkwamakmmky, ''); } }
