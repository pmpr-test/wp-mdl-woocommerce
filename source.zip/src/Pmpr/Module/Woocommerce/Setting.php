<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d005674d2d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce; use Pmpr\Common\Cover\Woocommerce\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { const qqiuqmkwamakmmky = self::soqkucakwksaeyce . "\166\141\x72\151\x61\x62\x6c\x65\x5f\160\x72\x6f\x64\165\143\x74\x5f\147\165\x69\x64\x65"; const kqaecmeyeicscaye = self::soqkucakwksaeyce . "\x73\150\x6f\160\137\x74\141\x62\x6c\145\137\166\151\145\x77\137\x63\157\154\165\x6d\x6e\x73"; public function qssqicawwgqqscui($ikgwqyuyckaewsow = []) { return $this->oaeygwkmgmgksqke([self::qqiuqmkwamakmmky => [Constants::qescuiwgsyuikume => __("\126\141\162\x69\x61\164\x69\157\156\40\120\x72\157\144\165\x63\164\x20\x47\x75\151\144\145", PR__MDL__WOOCOMMERCE)]], $ikgwqyuyckaewsow, self::imgaumeywmqsacas); } public static function ckgyyysykiycqwwm() { return self::iwgqamekocwaigci()->wikusamwomuogoau()->giiuwsmyumqwwiyq(self::qqiuqmkwamakmmky, ''); } }
