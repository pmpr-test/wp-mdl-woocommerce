<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517a734c48             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce; use Pmpr\Common\Cover\Woocommerce\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { const qqiuqmkwamakmmky = self::soqkucakwksaeyce . "\166\141\x72\x69\x61\142\154\x65\x5f\160\x72\157\x64\x75\143\x74\x5f\147\165\x69\144\145"; const kqaecmeyeicscaye = self::soqkucakwksaeyce . "\x73\150\x6f\160\137\164\141\142\154\x65\137\x76\151\x65\x77\x5f\143\157\x6c\165\155\x6e\x73"; public function qssqicawwgqqscui($ikgwqyuyckaewsow = []) { return $this->oaeygwkmgmgksqke([self::qqiuqmkwamakmmky => [Constants::qescuiwgsyuikume => __("\126\x61\162\151\x61\x74\151\157\156\40\120\x72\x6f\x64\x75\143\x74\40\x47\x75\151\x64\x65", PR__MDL__WOOCOMMERCE)]], $ikgwqyuyckaewsow, self::imgaumeywmqsacas); } public static function ckgyyysykiycqwwm() { return self::iwgqamekocwaigci()->wikusamwomuogoau()->giiuwsmyumqwwiyq(self::qqiuqmkwamakmmky, ''); } }
