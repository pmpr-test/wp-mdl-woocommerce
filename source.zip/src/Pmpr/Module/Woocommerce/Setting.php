<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc5c2b2411             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce; use Pmpr\Common\Cover\Woocommerce\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { const qqiuqmkwamakmmky = self::soqkucakwksaeyce . "\x76\141\x72\151\x61\x62\x6c\145\137\x70\x72\157\144\x75\143\164\137\147\x75\151\144\x65"; const kqaecmeyeicscaye = self::soqkucakwksaeyce . "\x73\x68\157\160\137\164\141\x62\x6c\145\x5f\x76\x69\145\167\x5f\x63\x6f\x6c\x75\155\156\163"; public function qssqicawwgqqscui($ikgwqyuyckaewsow = []) { return $this->oaeygwkmgmgksqke([self::qqiuqmkwamakmmky => [Constants::qescuiwgsyuikume => __("\126\x61\162\x69\141\164\151\x6f\156\40\120\x72\157\144\x75\143\164\40\107\x75\x69\x64\x65", PR__MDL__WOOCOMMERCE)]], $ikgwqyuyckaewsow, self::imgaumeywmqsacas); } public static function ckgyyysykiycqwwm() { return self::iwgqamekocwaigci()->wikusamwomuogoau()->giiuwsmyumqwwiyq(self::qqiuqmkwamakmmky, ''); } }
