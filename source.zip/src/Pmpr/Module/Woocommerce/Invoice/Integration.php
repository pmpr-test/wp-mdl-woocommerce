<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8c5ddb74             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce\Invoice; class Integration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\142\145\146\x6f\162\145\137\x69\x6e\166\x6f\151\143\145\137\x63\157\156\164\145\156\x74", [$this, "\141\157\x67\161\141\x77\x65\141\x67\x71\x67\143\151\x77\x61\x6f"])->qcsmikeggeemccuu("\x61\146\164\145\162\x5f\151\x6e\166\157\151\143\145\x5f\x63\x6f\x6e\x74\145\x6e\x74", [$this, "\x67\x71\167\163\x6d\x77\151\167\x61\163\171\x6d\x6b\143\163\x69"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if (!$sitepress) { goto esaqcqqwuussiiwo; } $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\167\x70\155\154\x5f\x6c\x61\156\x67\165\141\x67\x65", $umwqusowiqmyseom); if (!($swaukaagekiououo != '')) { goto qiiigwkqeoewsuwm; } $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); qiiigwkqeoewsuwm: esaqcqqwuussiiwo: } public function gqwsmwiwasymkcsi() { global $sitepress; if (!$sitepress) { goto ikqeeaysmqgcgawq; } $sitepress->switch_lang($sitepress->get_default_language()); ikqeeaysmqgcgawq: } }
