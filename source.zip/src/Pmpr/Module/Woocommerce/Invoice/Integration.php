<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517a734c48             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce\Invoice; class Integration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\142\145\x66\157\x72\145\x5f\151\x6e\x76\157\x69\143\145\137\143\x6f\156\x74\145\156\x74", [$this, "\x61\157\147\161\x61\x77\x65\x61\147\x71\147\143\151\167\x61\x6f"])->qcsmikeggeemccuu("\141\146\x74\145\x72\137\151\156\x76\157\151\143\145\137\143\x6f\x6e\164\x65\x6e\164", [$this, "\147\x71\167\x73\155\167\x69\167\x61\x73\171\155\x6b\x63\163\x69"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if (!$sitepress) { goto yqagomygmeoecwey; } $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\167\x70\155\154\x5f\154\x61\x6e\147\x75\x61\x67\x65", $umwqusowiqmyseom); if (!($swaukaagekiououo != '')) { goto qsgqwyqaqiowkmco; } $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); qsgqwyqaqiowkmco: yqagomygmeoecwey: } public function gqwsmwiwasymkcsi() { global $sitepress; if (!$sitepress) { goto qikaewekoecykeou; } $sitepress->switch_lang($sitepress->get_default_language()); qikaewekoecykeou: } }
