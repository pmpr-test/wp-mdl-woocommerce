<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ecddc864a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce\Invoice; class Integration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\142\x65\x66\157\162\x65\137\151\x6e\166\157\151\x63\145\x5f\143\x6f\x6e\164\145\x6e\x74", [$this, "\x61\157\147\x71\141\x77\x65\x61\x67\161\147\143\x69\167\x61\157"])->qcsmikeggeemccuu("\141\x66\164\x65\162\x5f\151\156\166\x6f\151\143\x65\137\x63\x6f\156\x74\145\x6e\164", [$this, "\147\161\167\x73\155\167\x69\167\141\x73\x79\x6d\x6b\143\x73\151"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if (!$sitepress) { goto esaqcqqwuussiiwo; } $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\x77\x70\155\x6c\137\154\141\156\x67\x75\141\147\x65", $umwqusowiqmyseom); if (!($swaukaagekiououo != '')) { goto qiiigwkqeoewsuwm; } $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); qiiigwkqeoewsuwm: esaqcqqwuussiiwo: } public function gqwsmwiwasymkcsi() { global $sitepress; if (!$sitepress) { goto ikqeeaysmqgcgawq; } $sitepress->switch_lang($sitepress->get_default_language()); ikqeeaysmqgcgawq: } }
