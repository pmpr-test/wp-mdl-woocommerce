<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7d3a0770             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce\Invoice; class Integration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\142\145\x66\x6f\x72\x65\x5f\151\156\166\x6f\x69\x63\145\x5f\143\157\156\164\145\x6e\x74", [$this, "\x61\157\x67\x71\x61\167\x65\x61\x67\x71\147\x63\151\167\x61\157"])->qcsmikeggeemccuu("\141\x66\164\145\x72\137\x69\x6e\166\x6f\x69\x63\x65\x5f\143\x6f\x6e\x74\x65\x6e\x74", [$this, "\x67\x71\x77\x73\x6d\x77\x69\x77\141\163\x79\x6d\153\x63\163\151"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if (!$sitepress) { goto esaqcqqwuussiiwo; } $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\167\x70\155\154\137\154\141\x6e\147\x75\x61\x67\145", $umwqusowiqmyseom); if (!($swaukaagekiououo != '')) { goto qiiigwkqeoewsuwm; } $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); qiiigwkqeoewsuwm: esaqcqqwuussiiwo: } public function gqwsmwiwasymkcsi() { global $sitepress; if (!$sitepress) { goto ikqeeaysmqgcgawq; } $sitepress->switch_lang($sitepress->get_default_language()); ikqeeaysmqgcgawq: } }
