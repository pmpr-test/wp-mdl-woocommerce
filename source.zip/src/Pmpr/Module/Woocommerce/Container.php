<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6801066135453             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { }
